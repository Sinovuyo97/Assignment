﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            string filess = "C:/Users/Geeks4Learning/Desktop/Testa.txt";
            string fileName = @"C:/Users/Geeks4Learning/Desktop/Testa.txt";

            string fname = "";
            string sname = "";
            string id = "";
            try
            {
                using (System.IO.StreamWriter writer = new System.IO.StreamWriter(fileName, true))
                {
                    
                        Console.WriteLine("Enter your name");
                        fname = Console.ReadLine();
                        Console.WriteLine("Enter Surname");
                        sname = Console.ReadLine();
                        Console.WriteLine("Enter your id number");
                        id = Console.ReadLine();
                        writer.Write($"{fname} ");
                        writer.WriteLine($"{sname} ");
                        sikhisi(fname, sname, id);
                        Console.WriteLine("Press to enter your details");
                        Console.ReadKey();
                    
                        
                    
                }
            }
            catch (Exception )
            {
                Console.WriteLine("It did not run!!");
            }
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            Console.WriteLine("Getting Connection ...");
            // Read using File.OpenText

            if (System.IO.File.Exists(filess))
            {
                using (System.IO.StreamReader sr = System.IO.File.OpenText(fileName))
                {
                    String input;
                    while ((input = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(input);
                    }
                    Console.WriteLine("END.");
                }
            }
            else
            {
                Console.WriteLine("File not found");
            }
            
            Console.WriteLine("File.Opentext Done - Neel wrote it");

            


            
           

            

            void sikhisi(string firstname, string lastname, string idnumber) 
            {
                //your connection string 
            string connString = @"Data Source = DESKTOP-DCEFN0U\SQLEXPRESS;Initial Catalog=Department;Integrated Security=True";

            //create instanace of database connection
            SqlConnection conn = new SqlConnection(connString);
                try
                {
                    Console.WriteLine("Openning Connection ...");

                    //open connection
                    conn.Open();

                    Console.WriteLine("Connection successful!");

                    StringBuilder strBuilder = new StringBuilder();

                    strBuilder.Append("INSERT INTO student_details(STUD_ID,STUD_NAME, STUD_SURNAME) VALUES ");
                    strBuilder.Append($"(N'{idnumber}',N'{firstname}',N'{lastname}')");


                    string sqlQuery = strBuilder.ToString();
                    using (SqlCommand command = new SqlCommand(sqlQuery, conn)) //pass SQL query created above and connection
                    {
                        command.ExecuteNonQuery(); //execute the Query
                        Console.WriteLine("Query Executed.");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Error: " + e.Message);
                }
            }
            

            Console.Read();
        }
    
    }
}
